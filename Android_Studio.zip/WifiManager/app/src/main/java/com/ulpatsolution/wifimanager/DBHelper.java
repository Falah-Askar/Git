package com.ulpatsolution.wifimanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "MyDB.db";
    public static final String DATA_TABLE_NAME = "DATA";
    public static final String DATA_COLUMN_ID = "ID";
    public static final String DATA_COLUMN_WIFIRESULT = "WIFIRESULT";
    public static final String DATA_COLUMN_DATE = "MYDATE";
    public static final String DATA_COLUMN_GLAT = "GLAT";
    public static final String DATA_COLUMN_GLON = "GLON";
    public static final String DATA_COLUMN_NLAT = "NLAT";
    public static final String DATA_COLUMN_NLON = "NLON";
    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table DATA(ID integer primary key, WIFIRESULT text,MYDATE text,GLAT text, GLON text,NLAT text,NLON text)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS DATA");
        onCreate(db);
    }
    public boolean insertData (String wifiresult, String date, String glat, String glon,String nlat,String nlon) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("WIFIRESULT", wifiresult);
        contentValues.put("MYDATE", date);
        contentValues.put("GLAT", glat);
        contentValues.put("GLON", glon);
        contentValues.put("NLAT", nlat);
        contentValues.put("NLON", nlon);
        db.insert("DATA", null, contentValues);
        return true;
    }
    public int RowsCount(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, DATA_TABLE_NAME);
        return numRows;
    }
    public Cursor getData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from DATA", null );
        return res;
    }
}
