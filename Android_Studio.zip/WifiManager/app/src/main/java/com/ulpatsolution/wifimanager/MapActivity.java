package com.ulpatsolution.wifimanager;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    SupportMapFragment mapFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap.clear();
        Cursor cursor=new DBHelper(MapActivity.this).getData();
        if(cursor.getCount()>0) {
            double lat=0;
            double lot=0;
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToPosition(i);
                String wifi_result = cursor.getString(1);
                String glat = cursor.getString(3);
                String glon = cursor.getString(4);
                String nlat = cursor.getString(5);
                String nlon = cursor.getString(6);

                lat = Double.parseDouble(glat);
                lot = Double.parseDouble(glon);
                googleMap.addMarker(new MarkerOptions()
                        .position(new LatLng(lat, lot))
                        .title(lat + "-" + lot)
                        .snippet(wifi_result));

            }
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lot), 20));
        }
    }
}
