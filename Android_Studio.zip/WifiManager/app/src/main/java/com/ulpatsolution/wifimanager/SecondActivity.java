package com.ulpatsolution.wifimanager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

    public class SecondActivity extends AppCompatActivity {
    private ListView wifiListview;
    private WifiManager wifiManager;
    private final int MY_PERMISSIONS_ACCESS_COARSE_LOCATION = 1;
    private static final int REQUEST_LOCATION = 123;
    WifiReceiver receiverWifi;
    public List<ScanResult> wifiList;
    double latitude = 0;
    double longitude = 0;
    Handler handler = new Handler();


    private Runnable periodicUpdate = new Runnable() {
        @Override
        public void run() {
            handler.postDelayed(periodicUpdate, 20 * 1000 - SystemClock.elapsedRealtime() % 1000);
            if (ContextCompat.checkSelfPermission(SecondActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(SecondActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);
            } else {
                wifiManager.startScan();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        wifiListview = findViewById(R.id.wifiList);
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if(wifiManager.isWifiEnabled()==false)
        {
            Toast.makeText(this, "Wifi is turned OFF please turn it on", Toast.LENGTH_SHORT).show();
            return;
        }

        handler.post(periodicUpdate);




    }

    public void ScanButton(View view) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);

        } else {
            wifiManager.startScan();
        }


    }

    public void SaveButton() {
        Location gpsLocation = new LocationService(this).getLocation(LocationManager.GPS_PROVIDER);
        Location nwLocation = new LocationService(this).getLocation(LocationManager.NETWORK_PROVIDER);

        if (gpsLocation != null) {
            latitude = gpsLocation.getLatitude();
            longitude = gpsLocation.getLongitude();
        }
        if (nwLocation != null) {
            latitude = nwLocation.getLatitude();
            longitude = nwLocation.getLongitude();
            Log.e("ASK", "Network " + latitude + " - - " + longitude);
        }



        if (wifiList.size() > 0) {
            int eduromfound=0;
            for (int i = 0; i < wifiList.size(); i++) {
                ScanResult scanResult = wifiList.get(i);
                if(scanResult.SSID.contains("eduroam"))
                {
                    eduromfound++;
                }
            }
            if(eduromfound==0){
                Toast.makeText(this, "eduroam Network Not Found", Toast.LENGTH_SHORT).show();
                LoadMap();
                return;
            }


            if (latitude == 0) {
                Toast.makeText(this, "Unable to fetch Location", Toast.LENGTH_SHORT).show();
            } else {
                for (int i = 0; i < wifiList.size(); i++) {
                    ScanResult scanResult = wifiList.get(i);
                    Date today = new Date();
                    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
                    String dateToStr = format.format(today);
                    if(scanResult.SSID.contains("eduroam"))
                    new DBHelper(SecondActivity.this).insertData(scanResult.SSID, dateToStr, String.valueOf(latitude), String.valueOf(longitude), String.valueOf(latitude), String.valueOf(longitude));
                }
                Toast.makeText(this, "Scan Successful", Toast.LENGTH_SHORT).show();
                LoadMap();
            }

        } else {
            Toast.makeText(this, "Wifi Is Not Avaliable", Toast.LENGTH_SHORT).show();
        }
    }

    public void LoadMap() {
        Intent in = new Intent(this, MapActivity.class);
        startActivity(in);
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        if(wifiManager.isWifiEnabled()==false)
        {
            Toast.makeText(this, "Wifi is turned OFF please turn it on", Toast.LENGTH_SHORT).show();
            return;
        }
        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE );
        boolean statusOfGPS = manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if(statusOfGPS==false)
        {
            Toast.makeText(this, "Please Turn On GPS", Toast.LENGTH_SHORT).show();
            return;
        }
        receiverWifi = new WifiReceiver(wifiManager, wifiListview);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        registerReceiver(receiverWifi, intentFilter);
        getWifi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiverWifi);
    }

    private void getWifi() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_LOCATION);

            } else {
                wifiManager.startScan();
            }
        } else {
            Toast.makeText(SecondActivity.this, "scanning", Toast.LENGTH_SHORT).show();
            wifiManager.startScan();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        switch (requestCode) {
            case REQUEST_LOCATION: {
                if (
                        (grantResults.length > 0) && (grantResults[0] + grantResults[1] == PackageManager.PERMISSION_GRANTED)
                ) {
                    wifiManager.startScan();
                    //Toast.makeText(mContext,"Permissions granted.",Toast.LENGTH_SHORT).show();
                } else {
                    // Permissions are denied
                    //Toast.makeText(mContext,"Permissions denied.",Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }

    }


    class LocationService extends Service implements LocationListener {
        protected LocationManager locationManager;
        Location location;

        private static final long MIN_DISTANCE_FOR_UPDATE = 0;
        private static final long MIN_TIME_FOR_UPDATE = 1000;

        public LocationService(Context context) {
            locationManager = (LocationManager) context.getSystemService(LOCATION_SERVICE);
        }

        @SuppressLint("MissingPermission")
        public Location getLocation(String provider) {
            if (locationManager.isProviderEnabled(provider)) {
                locationManager.requestLocationUpdates(provider, MIN_TIME_FOR_UPDATE, MIN_DISTANCE_FOR_UPDATE, this);
                if (locationManager != null) {
                    location = locationManager.getLastKnownLocation(provider);
                    return location;
                }
            }
            return null;
        }

        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }

        @Override
        public void onLocationChanged(Location location) {
            latitude = location.getLatitude();
            longitude = location.getLongitude();

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    }

    class WifiReceiver extends BroadcastReceiver {
        WifiManager wifiManager;
        StringBuilder sb;
        ListView wifiDeviceList;

        public WifiReceiver(WifiManager wifiManager, ListView wifiDeviceList) {
            this.wifiManager = wifiManager;
            this.wifiDeviceList = wifiDeviceList;
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(action)) {

                wifiList = wifiManager.getScanResults();
                ArrayList<String> deviceList = new ArrayList<>();
                for (ScanResult scanResult : wifiList) {
                    deviceList.add(scanResult.SSID);
                }
                ArrayAdapter arrayAdapter = new ArrayAdapter(context, android.R.layout.simple_list_item_1, deviceList.toArray());
                wifiDeviceList.setAdapter(arrayAdapter);
                SaveButton();

            }
        }
    }

}
